package com.example.devhive_friend_sanchez

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
